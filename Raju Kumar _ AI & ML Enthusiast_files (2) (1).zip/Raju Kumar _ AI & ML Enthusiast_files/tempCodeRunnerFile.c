<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Raju Kumar — AI/ML Portfolio</title>
  <meta name="description" content="Raju Kumar — B.Tech AIML student (Batch 2023-2027). Portfolio showcasing projects in AI/ML and web development.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0a0f1d;
      --accent: #00f5a0;
      --accent2: #00d9f5;
      --muted: #a8b3c6;
      font-family: 'Inter', system-ui;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: radial-gradient(circle at 20% 30%, rgba(0,245,160,0.1), transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(0,217,245,0.08), transparent 50%),
                  linear-gradient(180deg, #060a13 0%, #0a1224 100%);
      color: #e6eef6;
      -webkit-font-smoothing: antialiased;
      scroll-behavior: smooth;
    }

    .container { max-width: 1000px; margin: 0 auto; padding: 30px; }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .avatar {
      width: 58px; height: 58px;
      border-radius: 50%;
      border: 2px solid var(--accent);
      background: linear-gradient(135deg, #091424, #0e1a2e);
      display: flex; align-items: center; justify-content: center;
      font-weight: 700; color: var(--accent);
      box-shadow: 0 0 10px rgba(0,245,160,0.3);
    }

    nav a {
      color: var(--muted);
      margin-left: 16px;
      text-decoration: none;
      font-weight: 600;
      transition: color 0.3s ease;
    }
    nav a:hover { color: var(--accent2); }

    .hero {
      display: grid;
      grid-template-columns: 1fr 300px;
      gap: 24px;
      align-items: center;
      margin-top: 40px;
    }

    .card {
      background: rgba(255, 255, 255, 0.03);
      padding: 22px;
      border-radius: 12px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.3);
      backdrop-filter: blur(8px);
    }

    h1 { font-size: 28px; margin-bottom: 10px; }
    p.lead { color: var(--muted); }

    .btn {
      display: inline-block;
      padding: 10px 16px;
      border-radius: 10px;
      font-weight: 700;
      text-decoration: none;
      transition: 0.3s;
    }
    .btn-primary {
      background: linear-gradient(90deg, var(--accent), var(--accent2));
      color: #081218;
    }
    .btn-primary:hover { transform: scale(1.05); box-shadow: 0 0 12px var(--accent2); }
    .btn-ghost {
      border: 1px solid rgba(255,255,255,0.08);
      color: var(--muted);
      background: transparent;
    }

    img.profile {
      width: 100%;
      border-radius: 12px;
      border: 2px solid var(--accent);
      box-shadow: 0 0 18px rgba(0,245,160,0.2);
      transition: transform 0.4s ease;
    }
    img.profile:hover { transform: scale(1.05); }

    section { margin-top: 40px; }

    .skills { display: flex; gap: 10px; flex-wrap: wrap; }
    .skill-pill {
      background: rgba(255,255,255,0.05);
      padding: 8px 12px;
      border-radius: 999px;
      color: var(--muted);
      font-weight: 600;
      transition: 0.3s;
    }
    .skill-pill:hover { background: var(--accent2); color: #000; }

    .projects {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .project-card {
      background: rgba(255,255,255,0.03);
      border-radius: 10px;
      padding: 16px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .project-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 0 12px rgba(0,245,160,0.25);
    }

    footer {
      text-align: center;
      margin-top: 50px;
      color: var(--muted);
      font-size: 14px;
      padding-bottom: 20px;
    }

    @media(max-width: 880px){
      .hero { grid-template-columns: 1fr; }
      .projects { grid-template-columns: 1fr; }
    }
  </style>
</head>

<body>
  <div class="container">
    <header>
      <div class="brand">
        <div class="avatar">RK</div>
        <div>
          <div style="font-weight:700">Raju Kumar</div>
          <div style="font-size:12px;color:var(--muted)">B.Tech AIML (2023–2027)</div>
        </div>
      </div>
      <nav>
        <a href="#about">About</a>
        <a href="#education">Education</a>
        <a href="#skills">Skills</a>
        <a href="#projects">Projects</a>
        <a href="#contact">Contact</a>
      </nav>
    </header>

    <div class="hero">
      <div class="card">
        <h1>Hi, I’m Raju — AI & ML Enthusiast</h1>
        <p class="lead">I’m Raju Kumar, a B.Tech student specializing in Artificial Intelligence and Machine Learning. I love building intelligent systems, exploring data-driven solutions, and applying AI to real-world problems.</p>
        <div style="margin-top:16px;">
          <a class="btn btn-primary" href="resume.pdf" target="_blank">Download Resume</a>
          <a class="btn btn-ghost" href="#projects" style="margin-left:10px">View Projects</a>
        </div>
      </div>

      <div>
        <img src="raju.jpg" alt="Raju Kumar" class="profile">
      </div>
    </div>

    <section id="about" class="card">
      <h3>About</h3>
      <p style="color:var(--muted); margin-top:8px;">I am pursuing B.Tech in Artificial Intelligence & Machine Learning at Rungta College of Engineering and Technology (2023–2027). I’m passionate about machine learning, research, and building innovative AI-based projects.</p>
    </section>

    <section id="education" class="card">
      <h3>Education</h3>
      <table style="width:100%; margin-top:10px;">
        <tr><th>Degree</th><th>Institution</th><th>Year</th></tr>
        <tr><td><strong>B.Tech AIML</strong></td><td>Rungta College of Engineering & Technology</td><td>2023–2027</td></tr>
        <tr><td>12th</td><td>Dwarika H/S, Mandiri, Patna</td><td>2023</td></tr>
        <tr><td>10th</td><td>SHS Saraswati Dham, Basuhar, Punpun, Patna</td><td>2020</td></tr>
      </table>
    </section>

    <section id="skills" class="card">
      <h3>Skills</h3>
      <div class="skills" style="margin-top:10px;">
        <div class="skill-pill">Python</div>
        <div class="skill-pill">C</div>
        <div class="skill-pill">C++</div>
        <div class="skill-pill">Java</div>
        <div class="skill-pill">HTML</div>
        <div class="skill-pill">Machine Learning</div>
        <div class="skill-pill">Chatbot Development</div>
      </div>
    </section>

    <section id="projects" class="card">
      <h3>Projects</h3>
      <div class="projects" style="margin-top:10px;">
        <div class="project-card">
          <h4>AI Chatbot</h4>
          <p>A chatbot built using Python and NLP that handles user queries intelligently using rule-based and ML-driven intents.</p>
        </div>
        <div class="project-card">
          <h4>E-Commerce Website</h4>
          <p>A responsive online store built with HTML, CSS, and JavaScript featuring product pages, cart, and checkout mockup.</p>
        </div>
      </div>
    </section>

    <section id="contact" class="card">
      <h3>Contact</h3>
      <p style="color:var(--muted); margin-top:8px;">Reach out for collaboration, internships, or AI/ML discussions!</p>
      <div style="margin-top:12px; display:flex; gap:12px; flex-wrap:wrap;">
        <a class="btn btn-ghost" href="mailto:rajuofsskumar@gmail.com">Email</a>
        <a class="btn btn-ghost" href="https://apps.microsoft.com/detail/9WZDNCRFJ4Q7?hl=en-us&gl=IN&ocid=pdpshare" target="_blank">LinkedIn</a>
        <a class="btn btn-ghost" href="https://github.com/RajuKumar12221/azure-resume" target="_blank">GitHub</a>
      </div>
    </section>

    <footer>
      © Raju Kumar — B.Tech AIML (2023–2027) | Built with ❤️ | Hosted on Azure Blob Storage
    </footer>
  </div>
</body>
</html>
